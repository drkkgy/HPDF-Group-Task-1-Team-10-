# HPDF-Group-Task-1-Team-10-
(React Native)
Introduction to Notify!

The main motive of this app is to notify(simply push message) someone(registered with app) by using beautiful features and design.
The app functions like:
Login Screen:
The login screen mainly contains Username and Password based design which will login the (pre-registered)user.
It also has Register button which will go to the registration page and let the user register to the app.

![login](https://user-images.githubusercontent.com/34096221/35780681-2db60f96-0a05-11e8-8846-800e0ee1d472.png)


Register Screen:
The register screen contains the fields to be registered i.e. Firstname, Lastname, username, password, etc.
It has two buttons, either to Register(will register the user) or to Cancel(back to Login Screen).

![register](https://user-images.githubusercontent.com/34096221/35780690-5eff970c-0a05-11e8-8014-b548986f68d8.png)


Main App Screen:
It has the fields to enter the username and the message body to be push notified. It then does the verification of ID of the sender
and the receiver and then push notifies the receiver.
It also has a logout button which logs out the user from the app and gets back to Login Screen.

![mainapp](https://user-images.githubusercontent.com/34096221/35780712-95cb3a20-0a05-11e8-9385-d5f280cb31ad.png)
