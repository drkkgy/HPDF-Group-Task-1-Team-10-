import { AppRegistry } from 'react-native';
import ScreenChange from './App';

AppRegistry.registerComponent('hpdftask', () => ScreenChange);
